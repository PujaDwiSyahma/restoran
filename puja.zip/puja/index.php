<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant</title>
    <link rel="stylesheet" href="./dist/output.css">
</head>

<body class="w-full h-full flex flex-col bg-[url('/img/candy.jpg')] bg-cover">
    <nav class="flex justify-end items-end py-4 px-8 bg-teal-800 z-10">
        <a href="./auth/login.php" class="text-xl text-white font-bold font-sans hover:text-gray-500 duration-300">Login</a>
    </nav>
    <div class="flex flex-col w-full h-full justify-center items-center -mt-8">
        <div class="w-full h-screen justify-center items-center flex pt-2 flex-row px-8">
            <div class="w-2/3 flex flex-col shadow-xl">
                <span class="py-10 bg-teal-400 rounded text-white text-4xl font-bold w-full text-center">
                    SWEET RESTO🌟
                </span>
                <a href="./user/index.php" class="py-4 mt-4 bg-teal-600 font-bold text-center text-xl text-white rounded">Pesan Sekarang</a>
            </div>
            <!-- <div class="w-1/3 h-full flex flex-col">
                <img src="img/cake1.jpg" class="h-full" height="300">
            </div> -->
        </div>
    </div>
</body>

</html>
<?php

include("../config.php");
session_start();
if ($_SESSION["user"] == "") {
    echo "
    <script>
        alert('harap login terlebih dahulu, jika belom mempunyai akun silahkan ke admin')
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection, "SELECT * FROM tb_menu");

function createCart($data){
    global $connection;
    $id_user = $data["id_user"];
    $id_menu = $data["id_menu"];
    $quantity = $data["quantity"];
    $total = $quantity * $data["price"];

    mysqli_query($connection,"INSERT INTO tb_cart VALUES(
        '',
        '$id_user',
        '$id_menu',
        '$quantity',
        '$total'
    )");

    return mysqli_affected_rows($connection);
}

if(isset($_POST["submit"])){
    if(createCart($_POST) > 0 ){
        echo "
        <script>
            alert('keranjang di tambahkan')
            document.location.href = '../order/index.php'
        </script>
        ";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>

<body class="w-full flex flex-col justify-center items-center bg-gray-100">
    <nav class="w-full h-14 bg-teal-600 flex justify-between items-center px-10">
        <div class="text-white font-bold text-lg">
            <a href="#" class="hover:underline hover:underline-offset-4 mr-3">Home</a>
            <a href="../order/index.php" class="hover:underline hover:underline-offset-4 mr-3">Cart</a>
        </div>
        <div class="text-white font-bold text-lg">
            <a href="../auth/logout.php" class="hover:underline hover:underline-offset-4">Logout</a>
        </div>
    </nav>

    <!-- value for content index.php for admin -->

    <div class="flex flex-col justify-center items-center mt-16 mb-14 animate-bounce">
        <span class="py-4 px-8 bg-teal-500 font-bold text-lg rounded text-white">Selamat Datang dan Selamat Berbelanja</span>
    </div>

    <div class="container w-full h-full grid grid-cols-4 gap-4 mb-10">
        <?php while ($row = mysqli_fetch_assoc($menus)) : ?>
            <form action="" method="post" class="w-full h-full">
            <div class="flex flex-col py-2 px-4 border rounded-lg bg-white shadow-lg w-full h-full">
                <img src="../img/menu/<?= $row["image_menu"] ?>" class="my-2 rounded-lg" alt="">
                <div class="flex flex-col my-4 h-full justify-center items-start">
                    <span class="font-bold text-lg text-gray-800"><?= $row["name_menu"] ?></span>
                    <span class="font-bold text-lg text-gray-800">Price : Rp<?= $row["price_menu"] ?></span>
                </div>
                <div class="w-full flex-row flex justify-center items-center">
                    <input type="number" name="quantity" value="1" class="w-1/2 text-center py-1 font-semibold text-gray-800 text-lg focus:outline-none border border-teal-400 mb-2 rounded">
                    <button type="submit" name="submit" class="py-2 px-8 bg-teal-600 font-semibold text-lg rounded text-white border mb-2">Cart</button>
                </div>
            </div>
                <input type="hidden" name="id_user" value="<?= $_SESSION["id_user"] ?>">
                <input type="hidden" name="id_menu" value="<?= $row["id_menu"] ?>">
                <input type="hidden" name="price" value="<?= $row["price_menu"] ?>">
            </form>
        <?php endwhile ?>
    </div>
</body>

</html>
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./admin/*.{html,js,php}",
    "./user/*.{html,js,php}",
    "./menu/*.{html,js,php}",
    "./auth/*.{html,js,php}",
    "./order/*.{html,js,php}",
    "./index.php"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

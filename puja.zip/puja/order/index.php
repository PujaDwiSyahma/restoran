<?php

include("../config.php");
session_start();
if ($_SESSION["user"] == "") {
    header("location: ./index.php");
}

$id = (int)$_SESSION["id_user"];
// var_dump($id);

$carts = mysqli_query($connection, "SELECT * FROM tb_cart
        INNER JOIN tb_menu ON tb_menu.id_menu = tb_cart.id_menu
        INNER JOIN tb_user ON tb_user.id_user = tb_cart.id_user
        ORDER BY id_cart DESC
    ");

// var_dump(mysqli_fetch_assoc($carts));

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>

<body class="w-full flex flex-col justify-center items-center bg-gray-100">
    <nav class="w-full h-14 bg-teal-600 flex justify-between items-center px-10">
        <div class="text-white font-bold text-lg">
            <a href="../user/index.php" class="hover:underline hover:underline-offset-4 mr-3">Home</a>
            <a href="index.php" class="hover:underline hover:underline-offset-4 mr-3">Cart</a>
        </div>
        <div class="text-white font-bold text-lg">
            <a href="../auth/logout.php" class="hover:underline hover:underline-offset-4">Logout</a>
        </div>
    </nav>
    <div class="container w-full h-full flex justify-center items-center">
        <div class="w-full h-full flex flex-col justify-start items-start">
            <table class="table-auto text-center w-full my-12 shadow-xl">
                <thead>
                    <tr class="text-lg">
                        <th class="w-1/5 border-b-2 border-r-2 py-2 border-gray-500">Menu</th>
                        <th class="w-1/5 border-b-2 border-r-2 py-2 border-gray-500">Harga</th>
                        <th class="w-1/5 border-b-2 border-r-2 py-2 border-gray-500">Jumlah</th>
                        <th class="w-1/5 border-b-2 border-r-2 py-2 border-gray-500">Total</th>
                        <th class="w-1/5 border-b-2 border-r-2 py-2 border-gray-500">Action</th>
                    </tr>
                </thead>
                <?php while ($row = mysqli_fetch_assoc($carts)) : ?>
                    <?php if ($row["id_user"] == $id) { ?>
                        <tbody>
                            <tr>
                                <td class="py-2 border-b-2 border-r-2 border-gray-500 font-semibold text-lg"><?= $row["name_menu"] ?></td>
                                <td class="py-2 font-semibold border-b-2 border-r-2 text-lg border-gray-500 ">Rp<?= $row["price_menu"] ?></td>
                                <td class="py-2 font-semibold border-b-2 border-r-2 text-lg border-gray-500 "><?= $row["quantity"] ?>/pcs</td>
                                <td class="py-2 font-semibold border-b-2 border-r-2 text-lg border-gray-500 ">Rp<?= $row["total"] ?></td>
                                <td class="py-2 font-semibold border-b-2 border-r-2 text-lg border-gray-500 ">
                                    <a href="delete.php?id=<?= $row["id_cart"] ?>" class="text-red-700 hover:text-red-800 duration-300">
                                        delete
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    <?php } ?>
                <?php endwhile ?>
            </table>
            <div class="flex justify-end items-end w-full">
                <a href="../user/index.php" class="bg-red-600 py-2 px-8 font-semibold text-white rounded text-lg">Back</a>
            </div>
        </div>
    </div>
</body>

</html>
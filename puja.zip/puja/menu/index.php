<?php

include("../config.php");
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$menus = mysqli_query($connection, "SELECT * FROM tb_menu");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./../dist/output.css">
</head>

<body class="w-full flex flex-col justify-center items-center bg-teal-100">
    <nav class="w-full h-14 bg-teal-600 flex justify-between items-center px-10 mb-5">
        <div class="text-white font-bold text-lg">
            <a href="../admin/index.php" class="hover:underline hover:underline-offset-4 mr-3">Home</a>
            <a href="index.php" class="hover:underline hover:underline-offset-4">Menu</a>
        </div>
        <div class="text-white font-bold text-lg">
            <a href="../auth/logout.php" class="hover:underline hover:underline-offset-4">Logout</a>
        </div>
    </nav>

    <div class="container w-full h-full mb-6">
        <a href="create.php" class="py-2 px-4 bg-teal-500 font-bold text-white rounded hover:bg-teal-600 duration-300">
            Add Menu
        </a>
    </div>
    <div class="container w-full h-full grid grid-cols-3 gap-4 mb-4">
            <?php while ($row = mysqli_fetch_assoc($menus)) : ?>
                <div class="flex flex-col py-2 px-4 border border-teal-300 rounded-lg bg-teal-200 shadow-lg h-full">
                    <img src="../img/menu/<?= $row["image_menu"] ?>" class="my-2 rounded-lg h-52 w-52" alt="">
                    <div class="flex flex-col my-2 h-full justify-end items-start">
                        <span class="font-bold text-xl text-gray-800"><?= $row["name_menu"] ?></span>
                        <span class="font-bold text-xl text-gray-800">Price : Rp<?= $row["price_menu"] ?></span>
                    </div>
                    <div class="flex justify-end h-full items-end flex-row">
                        <a href="update.php?id=<?= $row["id_menu"] ?>" class="text-white py-2 px-4 bg-teal-600 hover:bg-teal-700 duration-300 font-bold text-lg mr-3 rounded">Edit</a>
                        <a href="delete.php?id=<?= $row["id_menu"] ?>" onclick="return confirm('ingin hapus data ini?')" class="text-white py-2 px-4 bg-rose-600 hover:bg-rose-700 duration-300 font-bold text-lg rounded">Delete</a>
                    </div>
                </div>
            <?php endwhile ?>
    </div>

</body>

</html>
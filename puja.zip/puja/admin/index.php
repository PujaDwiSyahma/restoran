<?php

include "../config.php";
session_start();
if ($_SESSION["admin"] == "") {
    echo "
    <script>
        document.location.href = '../auth/login.php'
    </script>
    ";
}

$users = mysqli_query($connection, "SELECT * FROM tb_user");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant</title>
    <link rel="stylesheet" href="../dist/output.css">
</head>

<body class="w-full flex flex-col justify-center items-center bg-teal-200">
    <nav class="w-full h-14 bg-teal-600 flex justify-between items-center px-10">
        <div class="text-white font-bold text-lg">
            <a href="#" class="hover:underline hover:underline-offset-4 mr-3">Home</a>
            <a href="../menu/index.php" class="hover:underline hover:underline-offset-4">Menu</a>
        </div>
        <div class="text-white font-bold text-lg">
            <a href="../auth/logout.php" class="hover:underline hover:underline-offset-4">Logout</a>
        </div>
    </nav>

    <!-- value for content index.php for admin -->

    <div class="flex flex-col justify-center items-center mt-16 mb-14 w-full">
        <span class="py-4 px-8 w-1/2 text-center animate-pulse font-bold text-xl rounded border shadow-lg bg-teal-100 border-teal-300 text-teal-500">Welcome Admin</span>
    </div>
    <div class="flex flex-col justify-end items-end mb-6 w-full container">
        <a href="create.php" class="py-3 px-8 border-2 border-teal-500 bg-teal-400 hover:bg-teal-500 duration-300 font-bold text-lg rounded text-white">Add User</a>
    </div>

    <div class="container w-full h-full grid grid-cols-3 gap-10">

        <?php while ($row = mysqli_fetch_assoc($users)) : ?>
            <div class="flex w-full h-full flex-col justify-start items-start">
                <div class="flex flex-col justify-start items-start border w-full px-10 pt-8 pb-4 rounded bg-teal-400">
                    <span class="text-white font-bold text-xl">Username : <?= $row["username"] ?></span>
                    <span class="text-white font-bold text-xl">Status : <?= $row["level"] ?></span>
                    <div class="w-full flex justify-center items-end">
                        <a href="update.php?id_biase=<?= $row["id_user"] ?>" class="py-2 px-6 mr-2 bg-teal-600 border-2 border-teal-200 mt-4 font-semibold text-white rounded">Edit</a>
                        <a href="delete.php?id_user=<?= $row["id_user"] ?>" class="py-2 px-6 border-2 bg-rose-600 mt-4 font-semibold text-white rounded">Delete</a>
                    </div>
                </div>
            </div>
        <?php endwhile ?>
    </div>
</body>

</html>